DROP TABLE IF EXISTS `#__evolutionary_action`;
DROP TABLE IF EXISTS `#__evolutionary_animation`;
DROP TABLE IF EXISTS `#__evolutionary_configuration`;
DROP TABLE IF EXISTS `#__evolutionary_texture`;
DROP TABLE IF EXISTS `#__evolutionary_breedable`;
